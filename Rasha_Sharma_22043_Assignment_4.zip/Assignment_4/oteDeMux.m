function output=oteDeMux(in,sel) 
    if sel(1)==0 
        output=otfDeMux(in,sel(2:3));
    elseif sel(1)==1
        i=otfDeMux(in,sel(2:3));
        if i(1)=="f0"
            i(1)="f4";
            output=i;
        elseif i(1)=="f1"
            i(1)="f5";
            output=i;
        elseif i(1)=="f2"
            i(1)="f6";
            output=i;
        elseif i(1)=="f3"
            i(1)="f7";
            output=i;
        end
    end 
end