function a=and1(x,y)   %function definition
if x*y==0              %implementing and condition
    a=0;
else
    a=1;
end                    %ending the if-else block                
end                    %ending the function definition