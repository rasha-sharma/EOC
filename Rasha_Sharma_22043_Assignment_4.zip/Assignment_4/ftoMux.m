%4-by-1 Mux
function f=ftoMux(d0,d1,d2,d3,s0,s1)
a=ttoMux(d0,d1,s0);
b=ttoMux(d2,d3,s0);
f=ttoMux(a,b,s1);
end