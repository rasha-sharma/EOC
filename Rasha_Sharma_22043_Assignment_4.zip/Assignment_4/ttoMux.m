%2-to-1
function f=ttoMux(d0,d1,s0)
a=and1(d0,not(s0));
b=and1(d1,s0);
f=or1(a,b);
end