%half adder
function [s, c]=halfAdder(a,b)
s=xor1(a,b);
c=and1(a,b);
end