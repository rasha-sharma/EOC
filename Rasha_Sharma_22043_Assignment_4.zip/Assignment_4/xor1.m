function f=xor1(x,y)   %function definition
a=not1(x);              %calling the not function defined previoulsy
b=not1(y);
c=and1(a,y);            %calling the and function defined previously
d=and1(x,b);
f=or1(c,d);             %calling the or function defined previously
end                     %ending the function definition