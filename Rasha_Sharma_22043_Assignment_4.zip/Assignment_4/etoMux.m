%8-to-1 Mux 
function f=etoMux(d0,d1,d2,d3,d4,d5,d6,d7,s0,s1,s2)
a=ftoMux(d0,d1,d2,d3,s0,s1);
b=ftoMux(d4,d5,d6,d7,s0,s1);
f=ttoMux(a,b,s2);
end