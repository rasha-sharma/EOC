%full adder
function [s,c]=fullAdder(x,y,z)
a=xor1(x,y);
s=xor1(a,z);
p=and1(x,y);
q=and1(s,z);
c=and1(p,q);
end 