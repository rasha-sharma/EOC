function output = otfDeMux(in,sel)  
    if sel(1) == 0 
        if sel(2) == 0 
            output = ["f0",string(in)];
        elseif sel(2) == 1
            output = ["f1",string(in)];
        end
    elseif sel(1) == 1
        if sel(2) == 0 
            output = ["f2",string(in)];
        elseif sel(2) == 1
            output = ["f3",string(in)];
        end
    end
end